---
name: "\U0001F680 Feature request"
about: Suggest an idea for this project
title: ''
labels: enhancement, help wanted
assignees: ''

---

## 🚀 Feature
<!-- Description of the feature proposal -->

### Motivation

<!-- Motivation for the proposal. Is your feature request related to a problem? 
If this is related to another GitHub issue, please link here too -->

### What you'd like

<!-- Description of what you want to happen. -->

### Alternatives

<!-- Description of any alternative solutions or features you've considered, if any. -->

### Additional context

<!-- Add any other context or screenshots about the feature request here. -->
