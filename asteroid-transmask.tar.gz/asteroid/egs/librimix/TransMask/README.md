### Results

|      |   task    |kernel size|chunk size|batch size|SI-SNRi(dB) | SDRi(dB)|
|:----:|:---------:|:---------:|:--------:|:--------:|:----------:|:-------:|
| Paper| sep_clean |    2     |      |         |        |     |
| Here | sep_clean |    2     |      |         |        |     |
