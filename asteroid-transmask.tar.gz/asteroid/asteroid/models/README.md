### Publishing models

- First, create a account on [Zenodo](https://zenodo.org/) 
(you can log in with GitHub directly)
- Then [create an access token](https://zenodo.org/account/settings/applications/tokens/new/), 
we'll need one to upload anything.

