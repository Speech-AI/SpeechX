from ..filterbanks import make_enc_dec
from ..masknn import StridedTransformerRNN
from .base_models import BaseTasNet


class TransMask(BaseTasNet):
    """ TransMask separation model, as described in [1].

    Args:
        n_src (int): Number of masks to estimate.
        ff_hid (int, optional): Number of neurons in the FF layer of Transformer
        chunk_size (int, optional): window size of overlap and add processing.
            Defaults to 100.
        hop_size (int or None, optional): hop size (stride) of overlap and add processing.
            Default to `chunk_size // 2` (50% overlap).
        n_repeats (int, optional): Number of repeats. Defaults to 6.
        norm_type (str, optional): Type of normalization to use. To choose from

            - ``'gLN'``: global Layernorm
            - ``'cLN'``: channelwise Layernorm
        ff_activation (str, optional): Which non-linear function for FF layer.
        encoder_activation (str, optional): Which non-linear function for filter
        mask_act (str, optional): Which non-linear function to generate mask.
        dropout (float, optional): Dropout ratio, must be in [0,1].
        in_chan (int, optional): Number of input channels, should be equal to
            n_filters.
        fb_name (str, className, optional): Filterbank family from which to make encoder
            and decoder. To choose among [``'free'``, ``'analytic_free'``,
            ``'param_sinc'``, ``'stft'``].
        kernel_size (int, optional): Length of the filters.
        n_filters (int, optional): Number of filters / Input dimension of the masker net.
        stride (int, optional): Stride of the convolution.
            If None (default), set to ``kernel_size // 2``.
        **fb_kwargs (dict, optional): Additional kwards to pass to the filterbank
            creation. (out_chan)

    References:
        [1] Zhang, Zining, Bingsheng He, and Zhenjie Zhang. "TransMask: A
         Compact and Fast Speech Separation Model Based on Transformer."
        arXiv preprint arXiv:2102.09978 (2021).
    """

    def __init__(
        self,
        n_src,
        ff_hid=256,
        chunk_size=100,
        hop_size=None,  # 50
        n_repeats=6,  # 2
        norm_type="gLN",
        ff_activation="relu",
        encoder_activation="relu",
        mask_act="relu",  # sigmoid
        dropout=0,
        in_chan=None,  # 64
        fb_name="free",
        kernel_size=16,
        n_filters=64,
        stride=8,
        **fb_kwargs,  # out_chan=64
    ):
        # encoder and decoder are just two conv1d, and they have independent filterbanks
        # 16, 8, 64 filter
        # encoder: conv1d on (1batch, 1, time) -> (1batch, freq/chan, stft_time)
        # decoder: conv1dtranspose on (1batch, freq, stft_time) -> (1batch, 1, time)
        # transpose is gradient of conv, not real deconv
        encoder, decoder = make_enc_dec(
            fb_name, kernel_size=kernel_size, n_filters=n_filters, stride=stride, **fb_kwargs
        )
        # it is n_filters
        n_feats = encoder.n_feats_out
        if in_chan is not None:
            assert in_chan == n_feats, (
                "Number of filterbank output channels"
                " and number of input channels should "
                "be the same. Received "
                f"{n_feats} and {in_chan}"
            )
        # Update in_chan
        masker = StridedTransformerRNN(
            n_feats,
            n_src,
            ff_hid=ff_hid,
            ff_activation=ff_activation,
            chunk_size=chunk_size,
            hop_size=hop_size,
            n_repeats=n_repeats,
            norm_type=norm_type,
            mask_act=mask_act,
            dropout=dropout,
        )
        super().__init__(encoder, masker, decoder, encoder_activation=encoder_activation)
