CLI
===

.. autofunction:: asteroid.scripts.asteroid_cli.upload
