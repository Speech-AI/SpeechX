### Model

- Model page: https://zenodo.org/record/3862942#.XtdrDxZ8Lg4
- Download URL: https://zenodo.org/record/3862942/files/model.pth?download=1
- Thanks to: @mpariente
