### Model

- Model page: https://zenodo.org/record/3873670#.XtdrwxZ8Lg4
- Download URL: https://zenodo.org/record/3873670/files/model.pth?download=1
- Thanks to: @mpariente