### Model

- Model page: https://zenodo.org/record/3903795#.XvEXL5Z8Lg5
- Download URL: https://zenodo.org/record/3903795/files/model.pth?download=1
- Thanks to: @mpariente