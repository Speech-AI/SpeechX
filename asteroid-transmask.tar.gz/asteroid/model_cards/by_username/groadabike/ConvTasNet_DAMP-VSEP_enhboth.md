### Model

- Model page: https://zenodo.org/record/3994193#.Xz_Jz3VKhGo
- Download URL: https://zenodo.org/record/3994193/files/model.pth?download=1
- Thanks to: @groadabike
