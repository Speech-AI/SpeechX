### Model

- Model page: https://zenodo.org/record/3874420#.XteDCRZ8Lg4
- Download URL: https://zenodo.org/record/3874420/files/model.pth?download=1
- Thanks to: @JorisCos
