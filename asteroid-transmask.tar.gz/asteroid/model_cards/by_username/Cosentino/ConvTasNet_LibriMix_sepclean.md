### Model

- Model page: https://zenodo.org/record/3873572#.Xtdq7hZ8Lg4
- Download URL: https://zenodo.org/record/3873572/files/model.pth?download=1
- Thanks to: @JorisCos
