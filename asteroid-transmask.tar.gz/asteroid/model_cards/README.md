### Model cards

Each model in our [Zenodo community](https://zenodo.org/communities/asteroid-models) 
has a model card here. 
You can search them by model, dataset or [uploader](./by_username).

### Adding a model card
You uploaded a model and you want to write a model card? 
Be sure to include the model's page, the download URL and its name.
