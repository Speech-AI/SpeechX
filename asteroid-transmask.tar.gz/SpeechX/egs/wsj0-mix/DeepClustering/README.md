Results will be updated soon

Deep clustering alone, with VAD weights 9.9 dB improvement (SDR)
MI alone: 10.0
Chimera: 11.5 