#!/bin/bash

storage_dir=/workspace/ssd-single-speaker/speech_separation
n_src=2
python_path=python

stage=0

. ./utils/parse_options.sh

current_dir=$(pwd)

if [[ $stage -le  0 ]]; then
    # Clone LibriMix repo
    git clone https://github.com/JorisCos/LibriMix

    # Run generation script
    cd LibriMix
    . generate_librimix.sh $storage_dir
fi

if [[ $stage -le  1 ]]; then
    cd $current_dir
    $python_path local/create_local_metadata.py --librimix_dir $storage_dir/Libri$n_src"Mix"
fi

