---
name: "\U0001F4DD Typos and doc fixes"
about: Typos and doc fixes
title: ''
labels: typo, documentation
assignees: ''

---

## 📚 Documentation

For typos and doc fixes, rather and submit a PR, thanks in advance!
